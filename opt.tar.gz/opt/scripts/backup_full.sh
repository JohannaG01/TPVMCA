#!/bin/bash
# cp ../../mnt/backup_full.sh /opt/scripts/
# prueba: backup_full.sh /var/log /backup_dir


# Mostrar ayuda si el usuario proporciona -help
if [ "$1" == "-help" ]; then
    echo "Uso: $0 <directorio_origen> <directorio_destino>"
    exit 0
fi

# Validar que se proporcionaron exactamente dos argumentos
if [ "$#" -ne 2 ]; then
    echo "Error: Debes proporcionar dos directorios."
    echo "Uso: $0 <directorio_origen> <directorio_destino>"
    exit 1
fi

origen="$1"
destino="$2"

# Obtener fecha actual en formato YYYYMMDD
fecha_actual=$(date +%Y%m%d)

# Obtener el nombre del directorio origen
carpeta=$(basename "$origen")

# Definir el nombre del archivo comprimido
archivo_backup="$carpeta-$fecha_actual.tar.gz"

echo "🔹 Origen: $origen"
echo "🔹 Destino: $destino"
echo "📂 Creando archivo comprimido: $archivo_backup"

# Validar que los directorios existen
if [ ! -d "$origen" ]; then
    echo " Error: El directorio origen '$origen' no existe."
    exit 1
fi

if [ ! -d "$destino" ]; then
    echo " Error: El directorio destino '$destino' no existe."
    exit 1
fi

# Comprimir archivos en un archivo .tar.gz
tar -czf "/tmp/$archivo_backup" -C "$origen" .

# Mover el archivo comprimido al destino
mv "/tmp/$archivo_backup" "$destino"

echo " Backup realizado exitosamente: $archivo_backup en $destino"
